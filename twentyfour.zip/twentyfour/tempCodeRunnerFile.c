  // allSolutions = NULL;
  // allSolutionsStrings = NULL;
