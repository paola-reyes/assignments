void searchAlbum(string remains, const map<string, set<string>> &albums) 
// {
//     // set<string> keywords;

//     // string keyword = "\0";

//     // while (!remains.empty()) {
//     //     splitFirstWord(remains, keyword, remains);
//     //     keywords.insert(keyword);
//     //     trimWhiteSpace(remains);
//     // }
// }


// void searchArtist(string remains, const map<string, set<string>> &artists) 
// {

// }

// void searchSong(string remains, const map<string, set<string>> &albums) 
// {

// }