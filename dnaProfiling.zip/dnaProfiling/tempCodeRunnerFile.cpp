            // // The remaining words of first line are the STR sequence. We don't neet to convert from an int
            // else if (firstLine && !readingName) {   
            //     pushString(thisPatient.dna.at(1), lineInput);   // Pushed into an ourvector of ourvector<char>'s. Similar to an ourvector<string>
            //     printVector(thisPatient.dna.at(1));
            // }
            // // The rest of the lines (name exlcuded) have a list of numbers. This is how many copies of each STR the patient has. Each number has it's corresponding STR
            // else if (!firstLine && !readingName) {
            //     printVector(thisPatient.dna.at(i));
            //     numToDNA(thisPatient.dna.at(i), stoi(lineInput), patientsList.at(i).dna.at(i));
            // }